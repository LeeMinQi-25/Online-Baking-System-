<?php
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$con = mysqli_connect('localhost', 'root', '','recipe_db');

// get the post records
$RName = $_POST['RName'];
$Type = $_POST['Type'];

// database insert SQL code
$sql = "INSERT INTO `recipe_tbl` (`Id`, `fldRName`, `fldType`) VALUES ('0', '$RName', '$Type')";

// insert in database 
$rs = mysqli_query($con, $sql);

if($rs)
{
	echo "Contact Records Inserted";
}

?>