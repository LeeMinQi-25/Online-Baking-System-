<?php
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$con = mysqli_connect('localhost', 'root', '','ingredient_db');

// get the post records
$Name = $_POST['Name'];
$Price = $_POST['Price'];
$Quantity = $_POST['Quantity'];

// database insert SQL code
$sql = "INSERT INTO `ingredient_db` (`Id`, `fldName`, `fldPrice`, `fldQuantity`) VALUES ('0', '$Name', '$Price', '$Quantity')";

// insert in database 
$rs = mysqli_query($con, $sql);

if($rs)
{
	echo "Contact Records Inserted";
}

?>